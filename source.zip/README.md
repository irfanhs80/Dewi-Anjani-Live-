# Dewi Anjani Live — GitHub Actions Release

Repository Android project for the Dewi Anjani Live Icecast streaming app.

## Build APK on GitHub

1. Upload/extract the **contents** of this ZIP into the root of your GitHub repository (not as a nested folder).
2. Ensure the default branch is `main`.
3. Open **Actions** → **Build Dewi Anjani Live Release APK** → **Run workflow**. A push to `main` also starts the build.
4. Open the successful run and download the `Dewi-Anjani-Live-Release` artifact.
5. Extract the artifact ZIP and install `Dewi-Anjani-Live-release.apk` on Android.

The workflow expects Android project files at repository root, uses Java 17, Android SDK 35 and Gradle 8.9, then builds and signs the APK.

## Important signing note

This workflow creates a temporary signing key for each run. It is suitable for testing/installing the APK, but **not** for reliable in-place upgrades: each run has a different signing certificate. To publish updates over an already installed release, configure a persistent keystore through GitHub Actions Secrets and use the same key for every release.

## Icecast

The app form is prefilled with the server host, port and mount shown in the supplied Alhastream panel. Enter the source username/password from your provider. The workflow only builds the Android app; successful streaming also depends on the provider accepting the app's Icecast source protocol and audio format.
