# Dewi Anjani Live

## Build APK dengan GitHub Actions
1. Ekstrak seluruh isi ZIP ke root repository (jangan mengunggah ZIP sebagai satu file).
2. Pastikan workflow berada di `.github/workflows/android-apk.yml`.
3. Push ke branch `main`, atau buka **Actions → Build Dewi Anjani Live APK → Run workflow**.
4. Setelah sukses, unduh artifact `Dewi-Anjani-Live-APK` dan pasang `app-debug.apk`.

Workflow memakai Java 17, Android SDK 35, dan Gradle 8.9. Tidak memerlukan `gradlew`.

## Catatan koneksi Icecast
Perbaikan menghindari pembacaan respons HTTP sebelum audio mulai dikirim, yang dapat membuat streaming tertahan pada status CONNECTING. Koneksi tetap bergantung pada server/provider yang menerima metode HTTP PUT, autentikasi, mountpoint, serta audio AAC/ADTS.

Aplikasi menggunakan mikrofon perangkat sebagai input audio. Masukkan password source di aplikasi; jangan menyimpan password produksi di repository.
