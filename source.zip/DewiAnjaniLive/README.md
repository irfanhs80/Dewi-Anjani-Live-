# Dewi Anjani Live — Icecast Android

## Build APK Release di GitHub
1. Buat repository baru dan upload seluruh isi folder proyek ini ke root repository (termasuk `.github/workflows/build-apk.yml`), atau upload ZIP proyek ke root.
2. Buka tab **Actions**, pilih **Build Dewi Anjani Live Release APK**, lalu **Run workflow**. Push ke `main` juga memicu build.
3. Setelah selesai, buka run yang sukses → **Artifacts** → `Dewi-Anjani-Live-Release` → unduh ZIP artifact dan ekstrak APK di dalamnya.

Workflow menghasilkan APK **Release** yang ditandatangani. Jika tidak mengatur signing secrets, workflow memakai kunci sementara; APK dapat dipasang, tetapi pembaruan berikutnya tidak dapat menimpa instalasi tersebut karena kunci berubah. Untuk rilis berkelanjutan, simpan keystore sendiri dan atur repository secrets: `RELEASE_KEYSTORE_BASE64`, `RELEASE_STORE_PASSWORD`, `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD`.

## Catatan
- Isi host dengan hostname server saja (tanpa `http://`), port, mount, username `source`, dan password Icecast.
- Pastikan mount Icecast menerima AAC/ADTS melalui HTTP PUT. Kecocokan codec/mount harus diuji dengan server yang digunakan.
- Android tetap menampilkan notifikasi foreground service saat mikrofon digunakan; ini perilaku wajib sistem dan tidak dapat dihilangkan dengan aman.
- Play Protect dapat menampilkan peringatan berdasarkan reputasi dan pemeriksaan Google. APK Release atau signing tidak menjamin peringatan tersebut hilang.
- Proyek sumber ini merupakan prototipe streaming. Uji di perangkat dan server sebenarnya sebelum siaran penting.
