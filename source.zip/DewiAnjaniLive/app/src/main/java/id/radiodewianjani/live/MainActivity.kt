package id.radiodewianjani.live

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private lateinit var host: EditText
    private lateinit var port: EditText
    private lateinit var mount: EditText
    private lateinit var user: EditText
    private lateinit var pass: EditText
    private lateinit var status: TextView
    private lateinit var start: Button
    private lateinit var meter: LinearLayout
    private val green = Color.rgb(0, 128, 96)
    private val dark = Color.rgb(20, 47, 39)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 248, 246))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        val hero = ImageView(this).apply {
            setImageResource(R.drawable.studio)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(dark, 18)
            clipToOutline = true
            contentDescription = "Studio Radio Dewi Anjani FM 104.6"
        }
        content.addView(hero, LinearLayout.LayoutParams(-1, dp(190)))
        text(content, "DEWI ANJANI LIVE", 25f, dark, true, 18)
        text(content, "Radio streaming • Icecast", 14f, Color.DKGRAY, false, 14)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(18))
            background = rounded(Color.WHITE, 18)
            elevation = dp(3).toFloat()
        }
        val cardParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        content.addView(card, cardParams)
        text(card, "DASHBOARD SIARAN", 18f, dark, true, 0)
        status = TextView(this).apply {
            text = "●  DISCONNECTED  •  Siap terhubung"
            textSize = 14f
            setTextColor(Color.rgb(180, 65, 45))
            setPadding(0, dp(12), 0, dp(12))
        }
        card.addView(status)
        text(card, "LEVEL AUDIO", 12f, Color.DKGRAY, true, 4)
        meter = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        repeat(20) { i ->
            val bar = View(this).apply {
                background = rounded(if (i < 10) Color.rgb(42, 166, 104) else if (i < 16) Color.rgb(232, 175, 45) else Color.rgb(204, 72, 65), 3)
                alpha = if (i < 2) .35f else .95f
            }
            val lp = LinearLayout.LayoutParams(0, dp(16), 1f).apply { marginEnd = dp(3) }
            meter.addView(bar, lp)
        }
        card.addView(meter)
        text(card, "Min: — dB     Max: — dB     (meter audio aktif saat siaran)", 12f, Color.GRAY, false, 7)
        text(content, "KONFIGURASI ICECAST", 18f, dark, true, 18)
        host = field(content, "Alamat server / hostname")
        port = field(content, "Port", "8000", InputType.TYPE_CLASS_NUMBER)
        mount = field(content, "Mount point", "/live.aac")
        user = field(content, "Username source", "source")
        pass = field(content, "Password source", "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        start = Button(this).apply {
            text = "MULAI SIARAN"
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            background = rounded(green, 14)
            setOnClickListener { startBroadcast() }
        }
        content.addView(start, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(18) })
        val stop = Button(this).apply {
            text = "HENTIKAN SIARAN"
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(183, 55, 48), 14)
            setOnClickListener {
                startService(Intent(this@MainActivity, StreamService::class.java).setAction(StreamService.ACTION_STOP))
                setDisconnected("Siaran dihentikan")
            }
        }
        content.addView(stop, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) })
        text(content, "Pastikan server Icecast menerima source melalui HTTP PUT dan mount mendukung AAC/ADTS.", 12f, Color.GRAY, false, 14)
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun field(parent: LinearLayout, hintText: String, value: String = "", type: Int = InputType.TYPE_CLASS_TEXT): EditText {
        val e = EditText(this).apply {
            hint = hintText
            inputType = type
            setText(value)
            textSize = 16f
            setSingleLine(true)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(Color.rgb(246, 248, 247), 10)
        }
        parent.addView(e, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(9) })
        return e
    }
    private fun text(parent: LinearLayout, value: String, size: Float, color: Int, bold: Boolean, top: Int) {
        val t = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        parent.addView(t, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun setDisconnected(message: String) {
        status.text = "●  DISCONNECTED  •  $message"
        status.setTextColor(Color.rgb(180, 65, 45))
        start.text = "MULAI SIARAN"
        start.background = rounded(green, 14)
    }

    private fun startBroadcast() {
        val h = host.text.toString().trim()
        val p = port.text.toString().toIntOrNull()
        val m = mount.text.toString().trim()
        val u = user.text.toString().trim()
        val pw = pass.text.toString()
        if (h.isBlank() || p == null || p !in 1..65535 || !m.startsWith("/") || u.isBlank() || pw.isBlank()) {
            status.text = "Lengkapi host, port, mount, username, dan password."
            status.setTextColor(Color.rgb(180, 65, 45))
            return
        }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            status.text = "Izinkan akses mikrofon, lalu tekan Mulai Siaran."
            return
        }
        val intent = Intent(this, StreamService::class.java).apply {
            action = StreamService.ACTION_START
            putExtra("host", h); putExtra("port", p); putExtra("mount", m)
            putExtra("user", u); putExtra("pass", pw)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        status.text = "●  CONNECTING  •  Menghubungkan ke Icecast…"
        status.setTextColor(Color.rgb(190, 130, 20))
        start.text = "MENGHUBUNGKAN…"
        start.background = rounded(Color.rgb(190, 130, 20), 14)
    }
}
